# Central — Design System Cilo / Responsive V2

Sistema visual reconstruído a partir das referências fornecidas do case Cilo, aplicado de forma consistente em desktop, notebook, tablet e mobile.

## Tokens principais

| Token | Valor | Uso |
|---|---|---|
| Black | `#121415` | texto principal, navegação ativa e ações primárias |
| Gray | `#676C74` | texto secundário |
| Mid Gray | `#DFDFDF` | bordas, divisórias e controles |
| Soft | `#F6F6F6` | fundo da aplicação e superfícies secundárias |
| White | `#FFFFFF` | cards, inputs e painéis |

Cores estruturais antigas, incluindo roxo, foram removidas. Cores fortes ficam restritas a estados semânticos: sucesso, risco, alerta e informação.

## Tipografia

- Família principal: **Geist Variable / Geist**.
- Hero Home: responsivo, aproximadamente 38–58 px no desktop e 34–38 px no mobile.
- Títulos de página: aproximadamente 30–42 px.
- Texto de interface: 9–15 px conforme hierarquia.
- Pesos dominantes: 500–600.

## Shell e navegação

### Desktop
- Rail lateral: 112 px em telas grandes e 96 px em notebooks.
- Botões de navegação: 58×58 px, ícones SVG de ~26 px.
- Main shell centralizado, com borda fina e raio de 24–30 px.
- Conteúdo limitado a aproximadamente 1520 px e centralizado.

### Tablet
- Rail reduzido para 84 px.
- Toolbars passam a quebrar em linhas sem comprimir busca/filtros.
- Grids de 4 colunas passam para 2 colunas.

### Mobile
- Navegação vira dock inferior de largura completa.
- Os 7 atalhos permanecem acessíveis no dock.
- Ícones ficam com ~23 px dentro de alvos de toque de ~47–52 px.
- Não existe overflow horizontal da página (`scrollWidth == viewport`).
- Tabela de tarefas deixa de ser uma tabela desktop espremida e vira cards verticais.
- Campanhas/TAP/calendários usam scroll local apenas quando o conteúdo realmente exige largura.

## Componentes

### Cards
- Fundo branco.
- Borda `#E6E6E6` / `#EBEBEB`.
- Raios de 16–18 px.
- Sem sombras decorativas no conteúdo principal.

### Inputs e selects
- Altura padrão: 42–46 px.
- Borda: 1.5 px `#DFDFDF`.
- Raio: 12–13 px.
- Focus ring preto.

### Botões
- Primário: `#121415`, texto branco.
- Secundário: branco, borda cinza.
- Alvos de clique aumentados em todas as páginas.

### Modais e drawers
- Raios de 22–24 px.
- Inputs e campos normalizados para o mesmo design system.
- Task detail vira uma superfície ampla no desktop e ocupa quase toda a tela no mobile.

## Páginas normalizadas

- Home
- Tarefas / Lista / Quadro / Por pessoa / Semana
- Detalhe de tarefa
- Entregas / handoffs
- Campanhas
- Workspace de campanha
- TAP
- Planejamento
- Mapa mental
- Calendário mensal
- Planejamento semanal
- Modais, drawers, formulários e filtros

## Breakpoints

- Grande desktop: `>= 1280 px`
- Notebook: `< 1280 px`
- Tablet: `< 900 px`
- Mobile: `< 640 px`
- Mobile estreito: `< 380 px`

## Persistência

O tema claro/escuro continua salvo em `central.theme`. A modularização da Home permanece salva por usuário no protótipo local e deve migrar para o perfil no Supabase quando a autenticação real for conectada.
