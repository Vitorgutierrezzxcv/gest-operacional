# Sistema de Entregas / Handoff — Central

## Fluxo implementado
- Entrega criada dentro de uma tarefa.
- Destinatário interno obrigatório.
- Próxima tarefa opcional, vinculando origem -> entrega -> próxima etapa.
- Mensagem/instruções da entrega.
- Links com título.
- Upload de imagens, vídeos, áudios, PDFs, documentos, planilhas e arquivos compactados.
- Opção de concluir a tarefa de origem ao enviar.
- Estados: enviado, recebido, ajustes solicitados, aprovado.
- Histórico de eventos da entrega.
- Página Entregas com Recebidos, Enviados e Todos (gestor).
- Entrega aparece tanto na tarefa de origem quanto na tarefa de destino.

## Persistência desta versão de protótipo
- Metadados de tarefas/entregas: localStorage.
- Arquivos enviados: IndexedDB do navegador.

## Produção
Para que Pedro envie em um dispositivo e Sarah receba em outro, migrar para:
- Supabase Auth (usuários e permissões)
- Postgres/Supabase (deliveries, delivery_recipients, delivery_events, task links)
- Supabase Storage (arquivos)
- RLS por marca, área, tarefa e destinatário
- notificações internas/WhatsApp/e-mail se desejado
